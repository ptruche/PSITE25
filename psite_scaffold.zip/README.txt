
PSITE scaffold
--------------
This archive contains placeholder directories for all topics.

Place your question .md files in:
  data/questions/<topic-slug>/

Each question should include YAML front-matter:
---
id: Q-001
subject: <Exact topic title from the app>
correct: A
A: Option A
B: Option B
C: Option C
D: Option D
E: Option E
---

Then the stem, followed by:
<!-- EXPLANATION -->
and the explanation.

Reviews go in:
  data/reviews/<topic-slug>.md

The app will auto-discover these.
